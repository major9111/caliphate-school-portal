"""Audit logs endpoint."""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from sqlalchemy import text
from typing import Optional
from app.core.database import get_db

router = APIRouter()


@router.get("/audit-logs")
def get_audit_logs(
    limit: int = Query(50, ge=1, le=100),
    offset: int = Query(0, ge=0),
    module: Optional[str] = None,
    user_id: Optional[str] = None,
    db: Session = Depends(get_db)
):
    db.execute(text("""
        CREATE TABLE IF NOT EXISTS audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT, user_id VARCHAR,
            action VARCHAR NOT NULL, module VARCHAR NOT NULL,
            resource_id VARCHAR, details TEXT, ip_address VARCHAR,
            user_agent TEXT, success BOOLEAN DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """))
    
    query = "SELECT * FROM audit_logs"
    conditions = []
    params = {}
    
    if module:
        conditions.append("module = :module")
        params["module"] = module
    if user_id:
        conditions.append("user_id = :user_id")
        params["user_id"] = user_id
    
    if conditions:
        query += " WHERE " + " AND ".join(conditions)
    
    query += " ORDER BY created_at DESC LIMIT :limit OFFSET :offset"
    params["limit"] = limit
    params["offset"] = offset
    
    result = db.execute(text(query), params)
    rows = result.fetchall()
    
    logs = []
    for row in rows:
        logs.append({
            "id": row[0], "user_id": row[1], "action": row[2], "module": row[3],
            "resource_id": row[4], "details": row[5], "ip_address": row[6],
            "user_agent": row[7], "success": bool(row[8]), "created_at": row[9]
        })
    
    return {"items": logs, "total": len(logs), "limit": limit, "offset": offset}
